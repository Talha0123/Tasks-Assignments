package com.example.sqlite_operation;

public class myDBAdapter {
    public static final String TABLE_NAME = ;

    public myDBAdapter(MainActivity mainActivity) {

    }

    public long insertData(String t1, String t2) {
    }

    public String getData() {
    }

    public char updateName(String u1, String u2) {
    }

    public int delete(String uname) {
    }
}
